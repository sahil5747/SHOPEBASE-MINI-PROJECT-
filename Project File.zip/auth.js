// js/auth.js — Login & Auth module

const AUTH = {
  currentUser: null,

  // Valid credentials (demo)
  credentials: [
    { email: 'admin@shopbase.com',   password: 'password123', role: 'Admin',   name: 'Admin User' },
    { email: 'manager@shopbase.com', password: 'password123', role: 'Manager', name: 'Manager User' },
    { email: 'viewer@shopbase.com',  password: 'password123', role: 'Viewer',  name: 'Viewer User' },
  ],

  permissions: {
    Admin:   { canEdit: true,  canDelete: true,  canInvite: true  },
    Manager: { canEdit: true,  canDelete: false, canInvite: false },
    Viewer:  { canEdit: false, canDelete: false, canInvite: false },
  },

  login(email, password) {
    const user = this.credentials.find(u => u.email === email && u.password === password);
    if (user) {
      this.currentUser = { ...user, permissions: this.permissions[user.role] };
      sessionStorage.setItem('shopbase_user', JSON.stringify(this.currentUser));
      return true;
    }
    return false;
  },

  logout() {
    this.currentUser = null;
    sessionStorage.removeItem('shopbase_user');
  },

  restore() {
    const saved = sessionStorage.getItem('shopbase_user');
    if (saved) {
      this.currentUser = JSON.parse(saved);
      return true;
    }
    return false;
  },

  can(action) {
    return this.currentUser?.permissions?.[action] || false;
  },
};

// ---- DOM helpers ----
let selectedRole = 'Admin';

function setRole(el) {
  document.querySelectorAll('.role-chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  selectedRole = el.dataset.role;
  const perms = { Admin: 'Full access', Manager: 'Edit & view only', Viewer: 'View only' };
  document.getElementById('perm-label').textContent = perms[selectedRole];

  // Pre-fill email hint based on role
  const emails = { Admin: 'admin@shopbase.com', Manager: 'manager@shopbase.com', Viewer: 'viewer@shopbase.com' };
  document.getElementById('email').value = emails[selectedRole];
}

function doLogin() {
  const email    = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const errorEl  = document.getElementById('login-error');

  if (AUTH.login(email, password)) {
    errorEl.style.display = 'none';
    showApp();
  } else {
    errorEl.style.display = 'block';
    errorEl.textContent = 'Invalid credentials. Use password123 to sign in.';
  }
}

function doLogout() {
  AUTH.logout();
  document.getElementById('app').style.display = 'none';
  document.getElementById('login-page').style.display = 'flex';
}

function showApp() {
  document.getElementById('login-page').style.display = 'none';
  document.getElementById('app').style.display = 'flex';

  // Update sidebar user info
  const u = AUTH.currentUser;
  document.getElementById('sidebar-name').textContent = u.name;
  document.getElementById('sidebar-role').textContent = u.role;
  document.getElementById('sidebar-avatar').textContent = u.name.split(' ').map(w => w[0]).join('').toUpperCase();

  // Init all pages
  renderCatalogue();
  renderReporting();
  renderUsers();
  navigate(document.querySelector('.nav-item[data-page="catalogue"]'), 'catalogue');
}

// Allow Enter key on login form
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('password').addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });

  // Try restoring session
  if (AUTH.restore()) {
    showApp();
  }
});
