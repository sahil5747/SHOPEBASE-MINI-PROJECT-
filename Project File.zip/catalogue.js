// js/catalogue.js — Product Catalogue module

function getStockBadge(stock) {
  if (stock === 0) return '<span class="badge badge-red">Out of stock</span>';
  if (stock < 10)  return `<span class="badge badge-amber">Low stock · ${stock}</span>`;
  return `<span class="badge badge-green">In stock · ${stock}</span>`;
}

function renderProductCard(p) {
  return `
    <div class="product-card" onclick="openProductModal(${p.id})">
      <div class="product-img">${p.emoji}</div>
      <div class="product-body">
        <div class="product-name">${p.name}</div>
        <div class="product-cat">${p.category}</div>
        <div class="product-price">₹${p.price.toLocaleString('en-IN')}</div>
        <div class="product-footer">${getStockBadge(p.stock)}</div>
      </div>
    </div>`;
}

function renderCatalogue(filter = '', category = 'All') {
  const products = DB.products.filter(p => {
    const matchName = p.name.toLowerCase().includes(filter.toLowerCase());
    const matchCat  = category === 'All' || p.category === category;
    return matchName && matchCat;
  });

  const categories = ['All', ...new Set(DB.products.map(p => p.category))];

  const catOptions = categories.map(c =>
    `<option value="${c}" ${c === category ? 'selected' : ''}>${c}</option>`
  ).join('');

  const canEdit = AUTH.can('canEdit');

  document.getElementById('catalogue-root').innerHTML = `
    <div class="toolbar">
      <div class="toolbar-left">
        <h2>Product Catalogue</h2>
        <p>${DB.products.length} products · ${new Set(DB.products.map(p => p.category)).size} categories</p>
      </div>
      <div class="toolbar-right">
        <div class="search-box">
          <i class="ti ti-search"></i>
          <input
            type="text"
            placeholder="Search products…"
            value="${filter}"
            oninput="renderCatalogue(this.value, document.getElementById('cat-filter').value)"
          />
        </div>
        <select id="cat-filter" class="filter-select"
          onchange="renderCatalogue(document.querySelector('#catalogue-root input').value, this.value)">
          ${catOptions}
        </select>
        ${canEdit ? `<button class="btn btn-primary" onclick="openAddProductModal()">
          <i class="ti ti-plus"></i> Add product
        </button>` : ''}
      </div>
    </div>

    ${products.length === 0
      ? `<div style="text-align:center; padding:48px; color:var(--text-secondary)">
           <i class="ti ti-package-off" style="font-size:36px; display:block; margin-bottom:12px;"></i>
           No products found
         </div>`
      : `<div class="product-grid">${products.map(renderProductCard).join('')}</div>`
    }
  `;
}

// ---- Product Detail Modal ----
function openProductModal(id) {
  const p = DB.products.find(x => x.id === id);
  if (!p) return;
  const canEdit = AUTH.can('canEdit');
  const canDelete = AUTH.can('canDelete');

  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h3>${p.emoji} ${p.name}</h3>
        <button class="modal-close" onclick="closeModal()"><i class="ti ti-x"></i></button>
      </div>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:8px;">
        <div>
          <div style="font-size:11px; color:var(--text-secondary); font-weight:600; text-transform:uppercase; margin-bottom:4px;">Category</div>
          <div style="font-size:14px;">${p.category}</div>
        </div>
        <div>
          <div style="font-size:11px; color:var(--text-secondary); font-weight:600; text-transform:uppercase; margin-bottom:4px;">Price</div>
          <div style="font-size:14px; font-weight:700; color:var(--primary);">₹${p.price.toLocaleString('en-IN')}</div>
        </div>
        <div>
          <div style="font-size:11px; color:var(--text-secondary); font-weight:600; text-transform:uppercase; margin-bottom:4px;">Stock</div>
          <div>${getStockBadge(p.stock)}</div>
        </div>
        <div>
          <div style="font-size:11px; color:var(--text-secondary); font-weight:600; text-transform:uppercase; margin-bottom:4px;">Status</div>
          <div>${p.status === 'active'
            ? '<span class="badge badge-green">Active</span>'
            : '<span class="badge badge-gray">Inactive</span>'}</div>
        </div>
      </div>
      <div class="modal-footer">
        ${canDelete ? `<button class="btn btn-danger" onclick="deleteProduct(${p.id})">
          <i class="ti ti-trash"></i> Delete
        </button>` : ''}
        ${canEdit ? `<button class="btn btn-primary" onclick="editProduct(${p.id})">
          <i class="ti ti-edit"></i> Edit
        </button>` : ''}
        <button class="btn" onclick="closeModal()">Close</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
}

function openAddProductModal() {
  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h3>Add new product</h3>
        <button class="modal-close" onclick="closeModal()"><i class="ti ti-x"></i></button>
      </div>
      <div class="form-group"><label>Product name</label><input type="text" id="new-name" placeholder="e.g. Bluetooth Speaker" /></div>
      <div class="form-group"><label>Category</label>
        <select class="filter-select" style="width:100%" id="new-cat">
          ${[...new Set(DB.products.map(p => p.category))].map(c => `<option>${c}</option>`).join('')}
        </select>
      </div>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div class="form-group"><label>Price (₹)</label><input type="number" id="new-price" placeholder="0" /></div>
        <div class="form-group"><label>Stock units</label><input type="number" id="new-stock" placeholder="0" /></div>
      </div>
      <div class="modal-footer">
        <button class="btn" onclick="closeModal()">Cancel</button>
        <button class="btn btn-primary" onclick="saveNewProduct()"><i class="ti ti-check"></i> Save product</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
}

function saveNewProduct() {
  const name  = document.getElementById('new-name').value.trim();
  const cat   = document.getElementById('new-cat').value;
  const price = parseInt(document.getElementById('new-price').value) || 0;
  const stock = parseInt(document.getElementById('new-stock').value) || 0;

  if (!name) { showToast('Please enter a product name', '⚠️'); return; }

  const newId = Math.max(...DB.products.map(p => p.id)) + 1;
  DB.products.push({ id: newId, name, category: cat, price, stock, emoji: '📦', status: 'active' });

  closeModal();
  renderCatalogue();
  showToast(`"${name}" added successfully`, '✅');
}

function deleteProduct(id) {
  const p = DB.products.find(x => x.id === id);
  DB.products.splice(DB.products.indexOf(p), 1);
  closeModal();
  renderCatalogue();
  showToast(`"${p.name}" removed`, '🗑️');
}

function editProduct(id) {
  closeModal();
  showToast('Edit mode — update product details above', '✏️');
}
