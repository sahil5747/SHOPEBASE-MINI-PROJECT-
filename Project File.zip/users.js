// js/users.js — User Management module

function roleBadge(role) {
  const map = { Admin: 'badge-blue', Manager: 'badge-amber', Viewer: 'badge-gray' };
  return `<span class="badge ${map[role] || 'badge-gray'}">${role}</span>`;
}

function statusBadge(status) {
  const map = { Active: 'badge-green', Inactive: 'badge-red', Pending: 'badge-amber' };
  return `<span class="badge ${map[status] || 'badge-gray'}">${status}</span>`;
}

function renderUsers(filter = '') {
  const canEdit   = AUTH.can('canEdit');
  const canDelete = AUTH.can('canDelete');
  const canInvite = AUTH.can('canInvite');

  const users = DB.users.filter(u =>
    u.name.toLowerCase().includes(filter.toLowerCase()) ||
    u.email.toLowerCase().includes(filter.toLowerCase())
  );

  const activeCount  = DB.users.filter(u => u.status === 'Active').length;
  const pendingCount = DB.users.filter(u => u.status === 'Pending').length;

  const rows = users.map(u => `
    <tr>
      <td>
        <div class="user-cell">
          <div class="mini-avatar" style="background:${u.avatarColor}; color:${u.avatarText};">${u.initials}</div>
          <div>
            <div style="font-weight:600; font-size:13px;">${u.name}</div>
            <div style="font-size:11px; color:var(--text-secondary);">${u.email}</div>
          </div>
        </div>
      </td>
      <td>${roleBadge(u.role)}</td>
      <td>${statusBadge(u.status)}</td>
      <td style="color:var(--text-secondary); font-size:12px;">${u.lastActive}</td>
      <td style="font-weight:600;">${u.orders}</td>
      <td>
        <div style="display:flex; gap:6px;">
          ${canEdit ? `<button class="btn" style="font-size:12px; padding:5px 10px;" onclick="openEditUserModal(${u.id})">
            <i class="ti ti-edit"></i> Edit
          </button>` : ''}
          ${canDelete ? `<button class="btn btn-danger" style="font-size:12px; padding:5px 10px;" onclick="deleteUser(${u.id})">
            <i class="ti ti-trash"></i>
          </button>` : ''}
          ${!canEdit && !canDelete ? `<span style="font-size:12px; color:var(--text-secondary);">View only</span>` : ''}
        </div>
      </td>
    </tr>`).join('');

  document.getElementById('users-root').innerHTML = `
    <div class="toolbar">
      <div class="toolbar-left">
        <h2>User Management</h2>
        <p>${activeCount} active · ${pendingCount} pending</p>
      </div>
      <div class="toolbar-right">
        <div class="search-box">
          <i class="ti ti-search"></i>
          <input type="text" placeholder="Search users…" value="${filter}"
            oninput="renderUsers(this.value)" />
        </div>
        <select class="filter-select" onchange="filterByRole(this.value)">
          <option value="">All roles</option>
          <option value="Admin">Admin</option>
          <option value="Manager">Manager</option>
          <option value="Viewer">Viewer</option>
        </select>
        ${canInvite ? `<button class="btn btn-primary" onclick="openInviteModal()">
          <i class="ti ti-user-plus"></i> Invite user
        </button>` : ''}
      </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:20px;">
      <div class="metric-card">
        <div class="metric-label">Total users</div>
        <div class="metric-value">${DB.users.length}</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Active</div>
        <div class="metric-value" style="color:var(--success);">${activeCount}</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Pending invite</div>
        <div class="metric-value" style="color:var(--warning);">${pendingCount}</div>
      </div>
    </div>

    <div class="card" style="padding:0; overflow:hidden;">
      <table class="data-table">
        <thead>
          <tr>
            <th style="padding-left:20px;">User</th>
            <th>Role</th>
            <th>Status</th>
            <th>Last active</th>
            <th>Orders</th>
            <th style="padding-right:20px;">Actions</th>
          </tr>
        </thead>
        <tbody>
          ${rows.length ? rows : `<tr><td colspan="6" style="text-align:center; padding:32px; color:var(--text-secondary);">No users found</td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}

function filterByRole(role) {
  const searchVal = document.querySelector('#users-root input')?.value || '';
  const users = DB.users.filter(u => {
    const matchSearch = u.name.toLowerCase().includes(searchVal.toLowerCase()) ||
                        u.email.toLowerCase().includes(searchVal.toLowerCase());
    const matchRole   = !role || u.role === role;
    return matchSearch && matchRole;
  });
  // Re-render with role filter applied
  renderUsersWithData(users);
}

function renderUsersWithData(users) {
  // simplified re-render for role filter
  const tbody = document.querySelector('#users-root .data-table tbody');
  if (!tbody) return;
  const canEdit   = AUTH.can('canEdit');
  const canDelete = AUTH.can('canDelete');

  tbody.innerHTML = users.map(u => `
    <tr>
      <td style="padding-left:20px;">
        <div class="user-cell">
          <div class="mini-avatar" style="background:${u.avatarColor}; color:${u.avatarText};">${u.initials}</div>
          <div>
            <div style="font-weight:600;">${u.name}</div>
            <div style="font-size:11px; color:var(--text-secondary);">${u.email}</div>
          </div>
        </div>
      </td>
      <td>${roleBadge(u.role)}</td>
      <td>${statusBadge(u.status)}</td>
      <td style="color:var(--text-secondary); font-size:12px;">${u.lastActive}</td>
      <td style="font-weight:600;">${u.orders}</td>
      <td>${canEdit ? `<button class="btn" style="font-size:12px;" onclick="openEditUserModal(${u.id})"><i class="ti ti-edit"></i> Edit</button>` : ''}</td>
    </tr>`).join('') || `<tr><td colspan="6" style="text-align:center; padding:32px; color:var(--text-secondary);">No users found</td></tr>`;
}

function openEditUserModal(id) {
  const u = DB.users.find(x => x.id === id);
  if (!u) return;

  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h3>Edit user — ${u.name}</h3>
        <button class="modal-close" onclick="closeModal()"><i class="ti ti-x"></i></button>
      </div>
      <div class="form-group"><label>Full name</label><input type="text" id="edit-name" value="${u.name}" /></div>
      <div class="form-group"><label>Email</label><input type="email" id="edit-email" value="${u.email}" /></div>
      <div class="form-group"><label>Role</label>
        <select class="filter-select" style="width:100%" id="edit-role">
          ${['Admin','Manager','Viewer'].map(r => `<option ${r===u.role?'selected':''}>${r}</option>`).join('')}
        </select>
      </div>
      <div class="form-group"><label>Status</label>
        <select class="filter-select" style="width:100%" id="edit-status">
          ${['Active','Inactive','Pending'].map(s => `<option ${s===u.status?'selected':''}>${s}</option>`).join('')}
        </select>
      </div>
      <div class="modal-footer">
        <button class="btn" onclick="closeModal()">Cancel</button>
        <button class="btn btn-primary" onclick="saveUserEdit(${u.id})"><i class="ti ti-check"></i> Save changes</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
}

function saveUserEdit(id) {
  const u = DB.users.find(x => x.id === id);
  u.name   = document.getElementById('edit-name').value.trim() || u.name;
  u.email  = document.getElementById('edit-email').value.trim() || u.email;
  u.role   = document.getElementById('edit-role').value;
  u.status = document.getElementById('edit-status').value;
  u.initials = u.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2);
  closeModal();
  renderUsers();
  showToast(`${u.name} updated`, '✅');
}

function deleteUser(id) {
  const u = DB.users.find(x => x.id === id);
  if (!u) return;
  if (confirm(`Remove ${u.name} from the system?`)) {
    DB.users.splice(DB.users.indexOf(u), 1);
    renderUsers();
    showToast(`${u.name} removed`, '🗑️');
  }
}

function openInviteModal() {
  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h3>Invite new user</h3>
        <button class="modal-close" onclick="closeModal()"><i class="ti ti-x"></i></button>
      </div>
      <div class="form-group"><label>Full name</label><input type="text" id="inv-name" placeholder="e.g. Deepika Rao" /></div>
      <div class="form-group"><label>Email address</label><input type="email" id="inv-email" placeholder="email@company.com" /></div>
      <div class="form-group"><label>Role</label>
        <select class="filter-select" style="width:100%" id="inv-role">
          <option>Viewer</option><option>Manager</option><option>Admin</option>
        </select>
      </div>
      <div class="modal-footer">
        <button class="btn" onclick="closeModal()">Cancel</button>
        <button class="btn btn-primary" onclick="sendInvite()"><i class="ti ti-send"></i> Send invite</button>
      </div>
    </div>`;
  document.body.appendChild(modal);
}

function sendInvite() {
  const name  = document.getElementById('inv-name').value.trim();
  const email = document.getElementById('inv-email').value.trim();
  const role  = document.getElementById('inv-role').value;

  if (!name || !email) { showToast('Please fill in all fields', '⚠️'); return; }

  const avatarColors = [
    { bg: '#E6F1FB', text: '#185FA5' },
    { bg: '#EAF3DE', text: '#3B6D11' },
    { bg: '#FAEEDA', text: '#854F0B' },
  ];
  const ac = avatarColors[DB.users.length % avatarColors.length];

  DB.users.push({
    id: DB.users.length + 1,
    name, email, role,
    status: 'Pending',
    lastActive: 'Never',
    orders: 0,
    initials: name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2),
    avatarColor: ac.bg,
    avatarText: ac.text,
  });

  closeModal();
  renderUsers();
  showToast(`Invite sent to ${name}`, '📧');
}
