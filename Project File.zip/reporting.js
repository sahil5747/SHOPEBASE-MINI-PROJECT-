// js/reporting.js — Reporting & Dashboard module

function orderStatusBadge(status) {
  const map = {
    Delivered:  'badge-green',
    Shipped:    'badge-blue',
    Processing: 'badge-amber',
    Returned:   'badge-red',
  };
  return `<span class="badge ${map[status] || 'badge-gray'}">${status}</span>`;
}

function buildBarChart(data) {
  const max = Math.max(...data.map(d => d.amount));
  return data.map(d => {
    const pct = Math.round((d.amount / max) * 100);
    const isMax = d.amount === max;
    return `
      <div class="bar-col">
        <div class="bar-fill ${isMax ? 'active' : ''}" style="height:${pct}%"></div>
        <div class="bar-label">${d.week}</div>
      </div>`;
  }).join('');
}

function buildDonut(data) {
  const r = 38, cx = 50, cy = 50, circumference = 2 * Math.PI * r;
  let offset = 0;
  const slices = data.map(d => {
    const dash = (d.pct / 100) * circumference;
    const gap  = circumference - dash;
    const rot  = (offset / 100) * 360 - 90;
    const slice = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none"
      stroke="${d.color}" stroke-width="16"
      stroke-dasharray="${dash.toFixed(1)} ${gap.toFixed(1)}"
      transform="rotate(${rot} ${cx} ${cy})" />`;
    offset += d.pct;
    return slice;
  }).join('');

  return `
    <svg viewBox="0 0 100 100" width="110" height="110">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#f1efe8" stroke-width="16"/>
      ${slices}
    </svg>`;
}

function renderReporting() {
  const totalRevenue = DB.weeklyRevenue.reduce((s, w) => s + w.amount, 0);
  const totalOrders  = DB.orders.length;
  const avgOrder     = Math.round(totalRevenue / totalOrders);

  const legendItems = DB.categoryStats.map(c => `
    <div style="display:flex; align-items:center; gap:8px; font-size:12px; color:var(--text-secondary);">
      <div style="width:10px; height:10px; border-radius:50%; background:${c.color}; flex-shrink:0;"></div>
      ${c.name} — ${c.pct}%
    </div>`).join('');

  const orderRows = DB.orders.map(o => `
    <tr>
      <td><span style="font-weight:600; color:var(--primary);">${o.id}</span></td>
      <td>${o.customer}</td>
      <td>${o.items} item${o.items > 1 ? 's' : ''}</td>
      <td style="font-weight:600;">₹${o.amount.toLocaleString('en-IN')}</td>
      <td>${orderStatusBadge(o.status)}</td>
      <td style="color:var(--text-secondary);">${new Date(o.date).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' })}</td>
    </tr>`).join('');

  document.getElementById('reporting-root').innerHTML = `
    <div class="toolbar">
      <div class="toolbar-left">
        <h2>Reporting Dashboard</h2>
        <p>Last 30 days performance overview</p>
      </div>
      <div class="toolbar-right">
        <select class="filter-select" onchange="showToast('Date filter applied','📅')">
          <option>Last 30 days</option>
          <option>Last 7 days</option>
          <option>Last 90 days</option>
          <option>This year</option>
        </select>
        <button class="btn" onclick="showToast('Report exported as CSV','📥')">
          <i class="ti ti-download"></i> Export
        </button>
      </div>
    </div>

    <div class="metrics-grid">
      <div class="metric-card">
        <div class="metric-label">Total Revenue</div>
        <div class="metric-value">₹${(totalRevenue/100000).toFixed(1)}L</div>
        <div class="metric-delta delta-up"><i class="ti ti-trending-up"></i> +12.4% vs last month</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Orders</div>
        <div class="metric-value">${(1200 + totalOrders).toLocaleString()}</div>
        <div class="metric-delta delta-up"><i class="ti ti-trending-up"></i> +8.1% vs last month</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Avg. Order Value</div>
        <div class="metric-value">₹${avgOrder.toLocaleString('en-IN')}</div>
        <div class="metric-delta delta-down"><i class="ti ti-trending-down"></i> –2.3% vs last month</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Return Rate</div>
        <div class="metric-value">3.2%</div>
        <div class="metric-delta delta-up"><i class="ti ti-trending-up"></i> Improved by 0.8%</div>
      </div>
    </div>

    <div class="charts-grid">
      <div class="card">
        <div class="card-title">Weekly revenue (₹)</div>
        <div class="bar-chart">${buildBarChart(DB.weeklyRevenue)}</div>
        <div style="margin-top:8px; font-size:11px; color:var(--text-secondary);">
          Peak week: W4 — ₹${(247000).toLocaleString('en-IN')}
        </div>
      </div>
      <div class="card">
        <div class="card-title">Sales by category</div>
        <div style="display:flex; align-items:center; gap:20px;">
          ${buildDonut(DB.categoryStats)}
          <div style="display:flex; flex-direction:column; gap:10px;">${legendItems}</div>
        </div>
      </div>
    </div>

    <div class="card" style="padding:0; overflow:hidden;">
      <div style="padding:16px 20px 0; display:flex; align-items:center; justify-content:space-between;">
        <div class="card-title" style="margin:0;">Recent orders</div>
        <button class="btn" style="font-size:12px;" onclick="showToast('Viewing all orders','📋')">
          View all <i class="ti ti-arrow-right"></i>
        </button>
      </div>
      <table class="data-table" style="margin:0;">
        <thead>
          <tr>
            <th style="padding:12px 20px 10px 20px;">Order ID</th>
            <th>Customer</th>
            <th>Items</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>${orderRows}</tbody>
      </table>
    </div>
  `;
}
