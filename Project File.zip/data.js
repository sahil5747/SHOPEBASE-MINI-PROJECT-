// js/data.js — Shared mock data for ShopBase

const DB = {

  // ---- PRODUCTS ----
  products: [
    { id: 1, name: 'Wireless Earbuds Pro',      category: 'Electronics', price: 2499, stock: 142, emoji: '📱', status: 'active' },
    { id: 2, name: 'Running Shoes X3',           category: 'Footwear',    price: 3999, stock: 8,   emoji: '👟', status: 'active' },
    { id: 3, name: 'Noise-Cancel Headphones',    category: 'Electronics', price: 5999, stock: 67,  emoji: '🎧', status: 'active' },
    { id: 4, name: 'Vitamin C Serum',            category: 'Beauty',      price: 899,  stock: 230, emoji: '🧴', status: 'active' },
    { id: 5, name: 'Smart Watch Series 4',       category: 'Electronics', price: 8999, stock: 0,   emoji: '⌚', status: 'inactive' },
    { id: 6, name: 'Ergonomic Office Chair',     category: 'Home',        price: 12499,stock: 14,  emoji: '🛋️', status: 'active' },
    { id: 7, name: 'Yoga Mat Premium',           category: 'Sports',      price: 1299, stock: 88,  emoji: '🧘', status: 'active' },
    { id: 8, name: 'Coffee Maker Deluxe',        category: 'Home',        price: 4599, stock: 23,  emoji: '☕', status: 'active' },
    { id: 9, name: 'Leather Wallet',             category: 'Accessories', price: 1499, stock: 55,  emoji: '👜', status: 'active' },
    { id:10, name: 'Mechanical Keyboard',        category: 'Electronics', price: 6999, stock: 31,  emoji: '⌨️', status: 'active' },
    { id:11, name: 'Sunglasses UV400',           category: 'Accessories', price: 1899, stock: 0,   emoji: '🕶️', status: 'inactive' },
    { id:12, name: 'Stainless Water Bottle',     category: 'Sports',      price: 799,  stock: 175, emoji: '🧊', status: 'active' },
  ],

  // ---- ORDERS ----
  orders: [
    { id: 'ORD-7821', customer: 'Priya Sharma',   items: 2, amount: 3498, status: 'Delivered', date: '2026-05-04' },
    { id: 'ORD-7820', customer: 'Rahul Mehta',    items: 1, amount: 899,  status: 'Shipped',   date: '2026-05-03' },
    { id: 'ORD-7819', customer: 'Ananya Singh',   items: 3, amount: 8997, status: 'Processing',date: '2026-05-03' },
    { id: 'ORD-7818', customer: 'Karan Joshi',    items: 1, amount: 5999, status: 'Returned',  date: '2026-05-02' },
    { id: 'ORD-7817', customer: 'Meera Pillai',   items: 4, amount: 9496, status: 'Delivered', date: '2026-05-01' },
    { id: 'ORD-7816', customer: 'Arjun Nair',     items: 2, amount: 6498, status: 'Shipped',   date: '2026-04-30' },
    { id: 'ORD-7815', customer: 'Divya Iyer',     items: 1, amount: 1299, status: 'Delivered', date: '2026-04-29' },
    { id: 'ORD-7814', customer: 'Sanjay Gupta',   items: 2, amount: 4598, status: 'Processing',date: '2026-04-28' },
  ],

  // ---- USERS ----
  users: [
    { id: 1, name: 'Priya Sharma',  email: 'priya@shopbase.com',   role: 'Admin',   status: 'Active',  lastActive: 'Today',        orders: 142, initials: 'PS', avatarColor: '#E6F1FB', avatarText: '#185FA5' },
    { id: 2, name: 'Rahul Mehta',   email: 'rahul@shopbase.com',   role: 'Manager', status: 'Active',  lastActive: 'Yesterday',    orders: 87,  initials: 'RM', avatarColor: '#EAF3DE', avatarText: '#3B6D11' },
    { id: 3, name: 'Ananya Singh',  email: 'ananya@shopbase.com',  role: 'Viewer',  status: 'Pending', lastActive: 'Never',        orders: 0,   initials: 'AS', avatarColor: '#FAEEDA', avatarText: '#854F0B' },
    { id: 4, name: 'Karan Joshi',   email: 'karan@shopbase.com',   role: 'Manager', status: 'Inactive',lastActive: '2 weeks ago',  orders: 56,  initials: 'KJ', avatarColor: '#FCEBEB', avatarText: '#A32D2D' },
    { id: 5, name: 'Meera Pillai',  email: 'meera@shopbase.com',   role: 'Viewer',  status: 'Active',  lastActive: '3 days ago',   orders: 34,  initials: 'MP', avatarColor: '#E6F1FB', avatarText: '#185FA5' },
    { id: 6, name: 'Arjun Nair',    email: 'arjun@shopbase.com',   role: 'Manager', status: 'Active',  lastActive: 'Today',        orders: 91,  initials: 'AN', avatarColor: '#EAF3DE', avatarText: '#3B6D11' },
  ],

  // ---- WEEKLY REVENUE ----
  weeklyRevenue: [
    { week: 'W1', amount: 148000 },
    { week: 'W2', amount: 193000 },
    { week: 'W3', amount: 132000 },
    { week: 'W4', amount: 247000 },
    { week: 'W5', amount: 172000 },
  ],

  // ---- CATEGORY STATS ----
  categoryStats: [
    { name: 'Electronics', pct: 40, color: '#185FA5' },
    { name: 'Clothing',    pct: 23, color: '#5DCAA5' },
    { name: 'Home',        pct: 20, color: '#EF9F27' },
    { name: 'Others',      pct: 17, color: '#D3D1C7' },
  ],
};
